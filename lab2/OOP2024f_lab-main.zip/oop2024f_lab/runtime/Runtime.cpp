#include <iostream>
#include <memory>
#include <vector>
#include "Interface/MonsterMovable.hpp"
#include "Object/GameObject.hpp"
#include "Util/Map.hpp"
#include "Util/RuntimeFramework.hpp"

namespace Util {

void RuntimeFramework::Initial() {
}

void RuntimeFramework::Running() {
}

void RuntimeFramework::Render() {
}

void RuntimeFramework::End() {}
};  // namespace Util
