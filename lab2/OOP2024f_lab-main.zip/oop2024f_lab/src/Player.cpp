#include "Object/Player.hpp"
#include "Object/GameObject.hpp"

namespace Object {

std::string Player::GetName() const {
};

Object::GamePosition Player::GetPosition() const {
};

void Player::Move(char direction) {
}

bool Player::IsOutRange() {
}

}  // namespace Object
