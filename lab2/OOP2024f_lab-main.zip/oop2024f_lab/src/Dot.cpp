#include "Object/Dot.hpp"

namespace Object {
Dot::Dot(Object::GamePosition pos)
    {};

uint8_t Dot::GetPoint() {
}

std::string Dot::GetName() const {
}

Object::GamePosition Dot::GetPosition() const {
}
}  // namespace Object
