#ifndef OOPLAB_ATTACKABLE_HPP
#define OOPLAB_ATTACKABLE_HPP

#include "string"

namespace Object {
class Attackable {
public:
    Attackable() = default;
    virtual ~Attackable() = default;
};
};  // namespace Object
#endif  // OOPLAB_ATTACKABLE_HPP
