//
// Created by 陳世昂 on 2024/11/12.
//

#include "System/MaintenanceSystem.hpp"

void RepairVehicle(std::shared_ptr<Vehicle> vehicle) {
}
