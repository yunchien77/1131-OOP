//
// Created by 陳世昂 on 2024/11/12.
//
#include "System/EnergyStation.hpp"
void EnergyStation::AddEnergy(int value) {
}

void EnergyStation::AddFuel(int value) {
}

int EnergyStation::GetEnergy() {
    return 0;
}
int EnergyStation::GetFuel() {
    return 0;
}
void EnergyStation::ChargeVehicle(std::shared_ptr<Vehicle> vehicle) {
}
